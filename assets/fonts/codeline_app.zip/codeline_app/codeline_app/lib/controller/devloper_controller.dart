import 'package:get/get.dart';

class DevloperController extends GetxController {}
