import 'package:get/get.dart';

class AddDevloperController extends GetxController {}
