class AppImages {
  static String badge = 'assets/images/badge.png';
  static String chart = 'assets/images/chart.png';
  static String student = 'assets/images/student.png';
  static String work = 'assets/images/work.png';
  static String logo = 'assets/images/CODELINE.svg';
}
