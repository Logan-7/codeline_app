enum DashBoardPanelScreens {
  dashboard,
  studentList,
  inquiryList,
  addStudent,
  fees,
  feesHistory,
  addInquiry,
  addDevloper,
  devloper,
  certificates
}
