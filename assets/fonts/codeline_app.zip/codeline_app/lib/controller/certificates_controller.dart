import 'package:codeline_app/widget/app_color.dart';
import 'package:codeline_app/widget/common_snackbar.dart';
import 'package:firedart/firestore/firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CertificatesController extends GetxController {
  DateTime? selectDate;
  DateTime? selectFirstDate;
  DateTime? selectLastDate;

  TextEditingController firstNameController = TextEditingController();
  TextEditingController middleNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController occupationController = TextEditingController();
  TextEditingController educationController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  OutlineInputBorder outlineInputBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: BorderSide(color: AppColor.grey400));

  /// update certificates type

  String certificateType = '';
  updateCertificateType(String value) {
    certificateType = value;
    update();
  }

  /// update gender type

  String genderType = '';
  updateGenderType(String value) {
    clearValue();
    genderType = value;
    update();
  }

  /// select certificate date

  selectedDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2010),
        lastDate: DateTime(2050));
    if (picked != null) {
      selectDate = picked;
    }

    update();
  }

  /// select first date

  selectedFirstDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2010),
        lastDate: DateTime.now());
    if (picked != null) {
      selectFirstDate = picked;
    }

    update();
  }

  /// select last date

  selectedLastDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: selectFirstDate!,
        lastDate: DateTime.now());
    if (picked != null) {
      selectLastDate = picked;
    }
    update();
  }

  ///Difference of firstdate and lastdate----------------------------------------------------------------------

  differenceDays(BuildContext context) {
    final difference = selectLastDate?.difference(selectFirstDate!).inDays;
    int months = difference! ~/ 30;
    print(months);
    return months;
  }

  /// add certificates data to firebase

  addCertificatesData(BuildContext context) async {
    if (certificateType == 'Course Completion Certificates') {
      try {
        await Firestore.instance.collection('Certificates').add(
          {
            'Date': DateTime.parse(selectDate!.toString()),
            'Gender': genderType,
            'FirstName': firstNameController.text,
            'LastName': lastNameController.text,
            'CertificateType': certificateType,
          },
        );
      } catch (e) {
        CommonSnackBar.getWarningSnackBar(context, 'Something went wrong');
      }
    } else {
      if (certificateType == 'Experience certificate') {
        try {
          await Firestore.instance.collection('Certificates').add(
            {
              'Date': DateTime.parse(selectDate!.toString()),
              'Gender': genderType,
              'FirstName': firstNameController.text,
              'LastName': lastNameController.text,
              'CertificateType': certificateType,
              'FirstDate': DateTime.parse(selectFirstDate!.toString()),
              'LastDate': DateTime.parse(selectLastDate!.toString()),
              'Occupation': occupationController.text
            },
          );
        } catch (e) {
          CommonSnackBar.getWarningSnackBar(context, 'Something went wrong');
        }
      } else {
        try {
          await Firestore.instance.collection('Certificates').add(
            {
              'Date': DateTime.parse(selectDate!.toString()),
              'Gender': genderType,
              'FirstName': firstNameController.text,
              'LastName': lastNameController.text,
              'CertificateType': certificateType,
              'FirstDate': DateTime.parse(selectFirstDate!.toString()),
              'LastDate': DateTime.parse(selectLastDate!.toString()),
              'CollageName': educationController.text,
              'Description': descriptionController.text,
            },
          );
        } catch (e) {
          CommonSnackBar.getWarningSnackBar(context, 'Something went wrong');
        }
      }
    }

    update();
  }

  clearValue() {
    genderType = '';
    firstNameController.clear();
    lastNameController.clear();
    middleNameController.clear();
    certificateType = '';
    occupationController.clear();
    educationController.clear();
    descriptionController.clear();
    selectDate = null;
    selectFirstDate = null;
    selectLastDate = null;
    update();
  }
}
